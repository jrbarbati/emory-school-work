Usage:
python main.py <training dataset> <test dataset> <output filename>

Instruction to get the given res.txt:
python main.py mushroom.training mushroom.test res.txt