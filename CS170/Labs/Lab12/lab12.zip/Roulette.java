
public class Roulette {

   public String[] value;
   public String[] color;

   public int outcome;

   /* ================================================
      TODO: Task 1: write the constructor
      ================================================ */
   public Roulette( ) {

   }


   /* ================================================
      TODO: Task 2: write the spin() method
      ================================================ */
   public void spin() {
   
   }


   /* ************************************************
      TODO: Task 2b: change the instance variable to  

                   private

      and recompile Test1.java and Test2.java

      You should get errors
      ************************************************ */

   /* ================================================
      TODO Task 3: write the getValue() method
      ================================================ */
   public String getValue() {
      return ""; //this return statement is wrong, write a correct one.
   }

   /* ================================================
      TODO Task 4: write the getColor() method
      ================================================ */
   public String getColor() {
      return ""; //this return statement is wrong, write a correct one.
   }

   /* ================================================
      TODO Task 5: write the toString() method
      ================================================ */
   public String toString() {	
		return ""; //this return statement is wrong, write a correct one.
   }

}



