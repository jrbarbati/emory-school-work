function explainTC()
%EXPLAINTC Prints explanation to TempConversion
%   Explains what the program TempConversion does
fprintf('TempConversion takes a min and max of degrees Fahrenheit and');
fprintf(' calculates the conversion to Celcius.\nThen it writes the matrix');
fprintf('out to the file FahrenheitConversion.dat\n');
end

