function writeTemps( inputMat )
%WRITETEMPS writes the matrix out to a file
%   saves the matrix out to a file called FahrenheitConversion.dat
save FahrenheitConversion.dat inputMat -ascii
end
