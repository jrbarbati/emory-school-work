function plotsin( xvec, min, max )
%PLOTSIN plots sin(x) from min to max
%   I couldn't figure out what do to with min and max :/
x = xvec;
y = sin(x);
plot(x, y, 'r+');

end

