DATE CREATED: 2016-03-16
LAST DATE UPDATED: 2016-03-16
AUTHOR: JOSEPH BARBATI
COURSE: CS 130R - Spring 2016

This directory contains MATLAB code and output generated for Homework 4.

INPUT
Various inputs as required by the programs (i.e user inputs - will be prompted)

CODE
nameCheck.m - function - makes sure an input string follows the form 'filename.ext'
toString.m - function - takes no args, generates two random numbers between 10 and 30 (inclusive) and returns a string of the concatenation of those numbers.
namedept.m - function - takes two strings(name, department) and returns an uppercase string of the first two letters of name and last two letters of department.
nchars.m - function - takes two args (chars, num) and returns a string of length num consisting of only chars
printLines - function - takes a vector of nested structures and prints the values of the line segments in tabluar form

OUTPUT
Various print or display statements, no separate docs

EXECUTION
In the HW4.m file, hit Run Section to run the scripts in there, otherwise call the functions in the command window with appropriate args
