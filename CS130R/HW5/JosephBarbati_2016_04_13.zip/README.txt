DATE CREATED: 2016-04-04
LAST DATE UPDATED: 2016-04-04
AUTHOR: JOSEPH BARBATI
COURSE: CS 130R - Spring 2016

This directory contains MATLAB code and output generated for Homework 5.

INPUT
Various inputs as required by the programs (i.e user inputs - will be prompted)
xypts.dat
mathfile.dat

CODE
plot2fnhand.m - function - takes two function handles and plots them from 1 to n
fibonacci.m - function - takes n as a arg, returns the nth fibonacci number

OUTPUT
Various print or display statements
3Dpoints.dat - file with points in the x, y, and z dimensions 
lenconv.mat - file containing Anon functions

EXECUTION
In the HW5.m file, hit Run Section to run the scripts in there, otherwise call the functions in the command window with appropriate args
