function [ fivesMat ] = fives( row, col )
%FIVES creates a row X column matrix of all 5s
%   Takes two arguements, row and col and will use this to build a zeros
%   matrix which the function will add 5 to each element and return the
%   fives matrix

zerosMat = zeros(row, col);
fivesMat = zerosMat + 5;

end

