%% flowrate
%Takes a metric measurement for flow rate as input and outputs the flow
%rate in non-metric units
flowRateMetric = input('Enter the flow in m^3/s: ');
flowRate = flowRateMetric / .028;
fprintf('A flow rate of %.3f meters per sec \n', flowRateMetric);
fprintf('is equivalent to %.3f feet per sec \n', flowRate);