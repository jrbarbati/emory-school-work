%% sinCosTan
%Asks user for a option between sin(x), cose(x) or tan(x), then prints what
%the user chose

answer = menu('Choose One', 'sin(X)', 'cos(X)', 'tan(X)');
fprintf('You chose: ');
if answer == 1
    fprintf('sin(X) \n');
elseif answer == 2
    fprintf('cos(X) \n');
else
    fprintf('tan(X) \n');
end