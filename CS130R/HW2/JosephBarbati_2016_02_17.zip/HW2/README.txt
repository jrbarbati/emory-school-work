DATE CREATED: 2016-02-07
LAST DATE UPDATED: 2016-02-07
AUTHOR: Joseph Barbati
COURSE: CS130R - Spring 2016

This directory contains MATLAB code and output generated for Homework 2.

INPUT
Various inputs required by scripts (will be prompted if necessary)

CODE
HW2.m - MATLAB script, various answers to questions that don't need functions or separate scripts
charScript.m - MATLAB script, prints a char twice, once one the left with 4 trailing spaces, and once on the right with 2 leading spaces
fives.m - MATLAB function, takes in a row and column argument and makes a matrix of all 5s 
flowrate.m - MATLAB script, takes a flow rate in m^3/s and outputs the conversion to ft^3/s
sinCosTan.m - MATLAB script, uses the menu function to ask user to select a function (sin, cos or tan) and prints what the user chose
windSpeed.m - MATLAB script, takes input for the mph of a storm and prints out the type of storm it is

OUTPUT
Various print statements described in the CODE section above

EXECUTION
This code is executed by running the code section-by-section in HW2
for the scripts and functions, calling the script or function in the command window will execute the code
For one of the questions, two figures will be produced, both showing sin(x) from 0 to pi
