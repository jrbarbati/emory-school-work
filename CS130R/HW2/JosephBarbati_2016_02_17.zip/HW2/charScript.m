%% charScript
%Takes a char as input and outputs the same char twice
%Once left-justified in a field width of 5 and another time
%right-justified with a field width of 3.
charInput = input('Please input a single character: ', 's');
fprintf('xx%-5sxx \t xx%3sxx \n', charInput, charInput);