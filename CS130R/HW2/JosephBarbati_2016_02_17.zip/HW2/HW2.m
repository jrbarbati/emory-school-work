%% Chapter 3 
% 5, 8, 11, 15, 30
%% Number 5
realNum = input('Please enter a real number of your choosing: ');
fprintf('You entered %.2f \n', realNum);

%% Number 8
%Separate Script called flowrate.m

%% Number 11
%Separate Script called charScript.m

%% Number 15 
figure(1);
x = 0: pi/10: pi;
y = sin(x);
plot(x, y, 'bo');
axis([0 pi -1 1]);
title('sin(x) from 0 to pi');
figure(2);
x = 0: pi/100: pi;
y = sin(x);
plot(x, y, 'r+');
axis([0 pi -1 1]);
title('sin(x) from 0 to pi');

%% Number 30
%Separate Function fives.m

%% Chapter 4
% 9, 21, 24, 30
%% Number 9
val = 0;
if val >= 10
    disp('Hello');
else 
    disp('Hi');
end

%% Number 21
%Separate Script windSpeed.m

%% Number 24
switch val
    case {0, 1, 2}
        yy(val)
    case 3
        tt(val)
    case {4, 5}
        mid(val)
    case 6
        ok(val)
    case {7, 8}
        xx(val)
    otherwise 
        yy(val)
end

%% Number 30
%Separate Script sinCosTan.m