%% windSpeed
%Asks user for wind speed of a particular storm and prints the type of
%storm it is
speed = input('What is the wind speed of the storm (mph)? ');
if speed <= 38
    fprintf('Tropical Depression \n');
elseif speed <= 73 
    fprintf('Tropical Storm \n');
else 
    fprintf('Hurricane \n');
end