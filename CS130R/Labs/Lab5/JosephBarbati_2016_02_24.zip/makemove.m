function [ r,c ] = makemove() 
%MAKEMOVE computer's move
r = randi([1,3]);
c = randi([1,3]);
end 